package com.fcproject;

import android.os.*;
import android.app.*;
import android.webkit.*;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#ffffff")); // warna bar color wajib hex
        }

        // Set up the webview
        WebView myWebView = (WebView) findViewById(R.id.webview);

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                String cookieStr = CookieManager.getInstance().getCookie(url); // android.webkit.CookieManager
                return super.shouldOverrideUrlLoading(view, url);
            }
        });

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setDomStorageEnabled(true);

        /*
        Contoh web view :
         String url = "https://example.com";
         myWebView.loadUrl(url);
         */

        /*
        Contoh Html :
        // String filePath = "file:///android_asset/index.html";
         myWebView.loadUrl(filePath);
         */
         
        String url = "https://example.com";
        myWebView.loadUrl(url);
    } // ends OnCreate

} // close of MainActivity